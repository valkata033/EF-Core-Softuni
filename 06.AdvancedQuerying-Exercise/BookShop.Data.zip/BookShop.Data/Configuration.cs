﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=DESKTOP-4F5UQ8E;Database=BookShop;Integrated Security=True;";
    }
}
