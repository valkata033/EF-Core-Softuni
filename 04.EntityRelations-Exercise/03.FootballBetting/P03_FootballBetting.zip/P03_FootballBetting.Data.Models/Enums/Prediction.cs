﻿namespace P03_FootballBetting.Data.Models.Enums
{
    public enum Prediction
    {
        HomeWin = 1,
        AwayWin = 2,
        Draw = 3
    }
}
