﻿namespace P03_FootballBetting.Data
{
    public static class Config
    {
        public const string ConnectionString =
            @"Server=DESKTOP-4F5UQ8E;Database=Bet365;Integrated Security=True;";
    }
}
