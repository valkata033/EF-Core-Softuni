﻿namespace P01_StudentSystem.Data
{
    public static class Config
    {
        public const string ConnectionString =
            @"Server=DESKTOP-4F5UQ8E;Database=StudentSystem;Integrated Security=True";
    }
}
