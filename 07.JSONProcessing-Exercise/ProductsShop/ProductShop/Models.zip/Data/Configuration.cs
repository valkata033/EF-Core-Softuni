﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string connectionString 
            = @"Server=DESKTOP-4F5UQ8E;Database=ProductShop;Integrated Security=True";
       
    }
}
