﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-4F5UQ8E;Database=MusicHub;Trusted_Connection=True";
    }
}
